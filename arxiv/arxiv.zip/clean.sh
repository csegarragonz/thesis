rm -f *.aux *.blg main.pdf *.log *.bbl *.toc *.glo *.ist *.acn *.acr
